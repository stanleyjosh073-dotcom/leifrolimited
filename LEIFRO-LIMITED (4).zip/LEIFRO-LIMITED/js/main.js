/* ==========================================================================
   LEIFRO LIMITED — Core JavaScript
   Handles: cart, wishlist, compare, quote requests, search/filter,
   hero slider, WhatsApp link building, mobile nav, back-to-top.
   Storage: browser localStorage (works when hosted / opened directly —
   not inside a sandboxed preview iframe).
   ========================================================================== */

const LEIFRO = {
  WHATSAPP_NUMBER: "2348035148710",
  STORAGE_KEYS: {
    cart: "leifro_cart",
    wishlist: "leifro_wishlist",
    compare: "leifro_compare"
  }
};

/* ---------------- Storage helpers ---------------- */
function getStore(key) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : [];
  } catch (e) {
    return [];
  }
}
function setStore(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (e) {
    console.warn("Storage unavailable:", e);
  }
}

/* ---------------- Cart ---------------- */
const Cart = {
  add(product, qty = 1) {
    const cart = getStore(LEIFRO.STORAGE_KEYS.cart);
    const existing = cart.find(i => i.id === product.id);
    if (existing) {
      existing.qty += qty;
    } else {
      cart.push({ ...product, qty });
    }
    setStore(LEIFRO.STORAGE_KEYS.cart, cart);
    updateHeaderCounts();
    showToast(`${product.name} added to cart`);
  },
  remove(id) {
    let cart = getStore(LEIFRO.STORAGE_KEYS.cart);
    cart = cart.filter(i => i.id !== id);
    setStore(LEIFRO.STORAGE_KEYS.cart, cart);
    updateHeaderCounts();
  },
  updateQty(id, qty) {
    const cart = getStore(LEIFRO.STORAGE_KEYS.cart);
    const item = cart.find(i => i.id === id);
    if (item) item.qty = Math.max(1, qty);
    setStore(LEIFRO.STORAGE_KEYS.cart, cart);
    updateHeaderCounts();
  },
  total() {
    return getStore(LEIFRO.STORAGE_KEYS.cart)
      .reduce((sum, i) => sum + i.price * i.qty, 0);
  },
  count() {
    return getStore(LEIFRO.STORAGE_KEYS.cart)
      .reduce((sum, i) => sum + i.qty, 0);
  }
};

/* ---------------- Wishlist ---------------- */
const Wishlist = {
  toggle(product) {
    let list = getStore(LEIFRO.STORAGE_KEYS.wishlist);
    const exists = list.find(i => i.id === product.id);
    if (exists) {
      list = list.filter(i => i.id !== product.id);
      showToast(`${product.name} removed from wishlist`);
    } else {
      list.push(product);
      showToast(`${product.name} added to wishlist`);
    }
    setStore(LEIFRO.STORAGE_KEYS.wishlist, list);
    updateHeaderCounts();
  },
  count() {
    return getStore(LEIFRO.STORAGE_KEYS.wishlist).length;
  }
};

/* ---------------- Compare ---------------- */
const Compare = {
  MAX: 4,
  toggle(product) {
    let list = getStore(LEIFRO.STORAGE_KEYS.compare);
    const exists = list.find(i => i.id === product.id);
    if (exists) {
      list = list.filter(i => i.id !== product.id);
    } else {
      if (list.length >= this.MAX) {
        showToast(`You can compare up to ${this.MAX} products`);
        return;
      }
      list.push(product);
    }
    setStore(LEIFRO.STORAGE_KEYS.compare, list);
    renderCompareBar();
  },
  count() {
    return getStore(LEIFRO.STORAGE_KEYS.compare).length;
  }
};

/* ---------------- WhatsApp order link builder ---------------- */
function buildWhatsAppLink(product) {
  const priceStr = product.price
    ? `₦${Number(product.price).toLocaleString()}`
    : "the listed price";
  const message =
    `Hello, I would like to order this machine.\n\n` +
    `Product: ${product.name}\n` +
    `Price: ${priceStr}\n` +
    (product.url ? `Link: ${product.url}` : "");
  return `https://wa.me/${LEIFRO.WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
}

function buildQuoteWhatsAppLink(formData) {
  const message =
    `Hello, I'd like to request a quote.\n\n` +
    `Name: ${formData.name || ""}\n` +
    `Business: ${formData.business || ""}\n` +
    `Product(s): ${formData.product || ""}\n` +
    `Quantity: ${formData.quantity || ""}\n` +
    `Notes: ${formData.notes || ""}`;
  return `https://wa.me/${LEIFRO.WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
}

/* ---------------- Toast ---------------- */
function showToast(msg) {
  let toast = document.querySelector(".toast-cart");
  if (!toast) {
    toast = document.createElement("div");
    toast.className = "toast-cart";
    document.body.appendChild(toast);
  }
  toast.textContent = msg;
  toast.style.display = "block";
  clearTimeout(toast._timer);
  toast._timer = setTimeout(() => (toast.style.display = "none"), 2200);
}

/* ---------------- Header counters ---------------- */
function updateHeaderCounts() {
  document.querySelectorAll("[data-cart-count]").forEach(el => {
    el.textContent = Cart.count();
    el.style.display = Cart.count() > 0 ? "flex" : "none";
  });
  document.querySelectorAll("[data-wishlist-count]").forEach(el => {
    el.textContent = Wishlist.count();
    el.style.display = Wishlist.count() > 0 ? "flex" : "none";
  });
}

/* ---------------- Compare bar render ---------------- */
function renderCompareBar() {
  const bar = document.getElementById("compareBar");
  if (!bar) return;
  const list = getStore(LEIFRO.STORAGE_KEYS.compare);
  bar.classList.toggle("show", list.length > 0);
  const names = bar.querySelector("[data-compare-names]");
  if (names) names.textContent = list.map(p => p.name).join(" · ");
  const countEl = bar.querySelector("[data-compare-count]");
  if (countEl) countEl.textContent = list.length;
}

/* ---------------- Hero slider ---------------- */
function initHeroSlider() {
  const slider = document.querySelector(".hero-slider");
  if (!slider) return;
  const slides = slider.querySelectorAll(".slide");
  const dotsWrap = slider.querySelector(".slider-dots");
  if (slides.length <= 1) return;

  let current = 0;
  slides.forEach((s, i) => {
    const dot = document.createElement("button");
    if (i === 0) dot.classList.add("active");
    dot.addEventListener("click", () => goTo(i));
    dotsWrap.appendChild(dot);
  });

  function goTo(index) {
    slides[current].classList.remove("active");
    dotsWrap.children[current].classList.remove("active");
    current = index;
    slides[current].classList.add("active");
    dotsWrap.children[current].classList.add("active");
  }

  setInterval(() => goTo((current + 1) % slides.length), 6000);
}

/* ---------------- Product tab filter (Best Selling / New / On Sale) ---------------- */
function initProductTabs() {
  document.querySelectorAll("[data-tab-group]").forEach(group => {
    const buttons = group.querySelectorAll("[data-tab]");
    const groupName = group.getAttribute("data-tab-group");
    const panels = document.querySelectorAll(`[data-tab-panel="${groupName}"]`);
    buttons.forEach(btn => {
      btn.addEventListener("click", () => {
        buttons.forEach(b => b.classList.remove("active"));
        btn.classList.add("active");
        const target = btn.getAttribute("data-tab");
        panels.forEach(p => {
          p.style.display = p.getAttribute("data-tab-value") === target ? "" : "none";
        });
      });
    });
  });
}

/* ---------------- Shop page: live filtering ---------------- */
function initShopFilters() {
  const grid = document.getElementById("shopGrid");
  if (!grid) return;
  const cards = grid.querySelectorAll("[data-product-card]");
  const searchInput = document.getElementById("shopSearch");
  const categoryChecks = document.querySelectorAll("[data-filter-category]");
  const sortSelect = document.getElementById("shopSort");

  function applyFilters() {
    const query = (searchInput?.value || "").toLowerCase();
    const activeCats = Array.from(categoryChecks)
      .filter(c => c.checked)
      .map(c => c.value);

    let visibleCount = 0;
    cards.forEach(card => {
      const name = card.getAttribute("data-name").toLowerCase();
      const cat = card.getAttribute("data-category");
      const matchesQuery = !query || name.includes(query);
      const matchesCat = activeCats.length === 0 || activeCats.includes(cat);
      const visible = matchesQuery && matchesCat;
      card.style.display = visible ? "" : "none";
      if (visible) visibleCount++;
    });

    const countEl = document.getElementById("resultCount");
    if (countEl) countEl.textContent = visibleCount;
  }

  function applySort() {
    if (!sortSelect) return;
    const value = sortSelect.value;
    const cardArray = Array.from(cards);
    cardArray.sort((a, b) => {
      const priceA = parseFloat(a.getAttribute("data-price"));
      const priceB = parseFloat(b.getAttribute("data-price"));
      if (value === "price-asc") return priceA - priceB;
      if (value === "price-desc") return priceB - priceA;
      return 0;
    });
    cardArray.forEach(c => grid.appendChild(c));
  }

  searchInput?.addEventListener("input", applyFilters);
  categoryChecks.forEach(c => c.addEventListener("change", applyFilters));
  sortSelect?.addEventListener("change", applySort);
}

/* ---------------- Product detail: gallery + qty stepper ---------------- */
function initProductDetail() {
  document.querySelectorAll(".product-gallery-thumbs .thumb").forEach(thumb => {
    thumb.addEventListener("click", () => {
      document.querySelectorAll(".product-gallery-thumbs .thumb")
        .forEach(t => t.classList.remove("active"));
      thumb.classList.add("active");
      const mainImg = document.querySelector("[data-gallery-main]");
      if (mainImg) mainImg.style.backgroundImage = thumb.style.backgroundImage;
    });
  });

  document.querySelectorAll(".qty-stepper").forEach(stepper => {
    const input = stepper.querySelector("input");
    stepper.querySelector("[data-qty-minus]")?.addEventListener("click", () => {
      input.value = Math.max(1, parseInt(input.value || "1") - 1);
    });
    stepper.querySelector("[data-qty-plus]")?.addEventListener("click", () => {
      input.value = parseInt(input.value || "1") + 1;
    });
  });
}

/* ---------------- Newsletter + Quote + Contact forms ---------------- */
function initForms() {
  document.querySelectorAll("[data-newsletter-form]").forEach(form => {
    form.addEventListener("submit", e => {
      e.preventDefault();
      showToast("Subscribed! Watch your inbox for new arrivals.");
      form.reset();
    });
  });

  document.querySelectorAll("[data-quote-form]").forEach(form => {
    form.addEventListener("submit", e => {
      e.preventDefault();
      const data = Object.fromEntries(new FormData(form).entries());
      window.open(buildQuoteWhatsAppLink(data), "_blank");
    });
  });

  document.querySelectorAll("[data-contact-form]").forEach(form => {
    form.addEventListener("submit", e => {
      e.preventDefault();
      showToast("Message sent. We'll reply within 24 hours.");
      form.reset();
    });
  });
}

/* ---------------- Back to top ---------------- */
function initBackToTop() {
  const btn = document.querySelector(".back-to-top");
  if (!btn) return;
  window.addEventListener("scroll", () => {
    btn.style.display = window.scrollY > 400 ? "flex" : "none";
  });
  btn.addEventListener("click", () => window.scrollTo({ top: 0, behavior: "smooth" }));
}

/* ---------------- Scroll reveal animations ---------------- */
function initScrollReveal() {
  const items = document.querySelectorAll("[data-reveal]");
  if (!items.length || !("IntersectionObserver" in window)) return;
  const observer = new IntersectionObserver(
    entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add("reveal-visible");
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.15 }
  );
  items.forEach(el => observer.observe(el));
}

/* ---------------- Init ---------------- */
document.addEventListener("DOMContentLoaded", () => {
  updateHeaderCounts();
  renderCompareBar();
  initHeroSlider();
  initProductTabs();
  initShopFilters();
  initProductDetail();
  initForms();
  initBackToTop();
  initScrollReveal();

  // Wire up any element with data-add-to-cart / data-add-to-wishlist / data-add-to-compare
  document.querySelectorAll("[data-add-to-cart]").forEach(btn => {
    btn.addEventListener("click", e => {
      e.preventDefault();
      const product = JSON.parse(btn.getAttribute("data-product"));
      Cart.add(product);
    });
  });
  document.querySelectorAll("[data-add-to-wishlist]").forEach(btn => {
    btn.addEventListener("click", e => {
      e.preventDefault();
      const product = JSON.parse(btn.getAttribute("data-product"));
      Wishlist.toggle(product);
    });
  });
  document.querySelectorAll("[data-add-to-compare]").forEach(btn => {
    btn.addEventListener("click", e => {
      e.preventDefault();
      const product = JSON.parse(btn.getAttribute("data-product"));
      Compare.toggle(product);
    });
  });
});
