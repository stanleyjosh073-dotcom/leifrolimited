# LEIFRO LIMITED — E-commerce Platform

Printing machine &amp; equipment marketplace for Leifro Limited (Abuja, Nigeria).

## Contact
- Address: Suite 23, Block B, Commerce Plaza, Area 1, Garki, Abuja
- Phone / WhatsApp: 0803 514 8710
- Email: leifrolimited@gmail.com

## What's built so far (Phase 1 — Frontend)

```
LEIFRO-LIMITED/
├── index.html              Homepage (hero slider, categories, featured products, testimonials)
├── css/
│   └── style.css           Full design system (colors, type, components)
├── js/
│   └── main.js             Cart, wishlist, compare, search/filter, sliders, forms
├── images/                 icons / banners / products (add your photos here)
├── pages/
│   ├── shop.html             Full catalog with sidebar filters, search, sort
│   ├── product-detail.html   Single product template (gallery, specs, related items)
│   ├── cart.html             Cart with live totals + WhatsApp checkout
│   ├── wishlist.html         Saved items, move-to-cart
│   ├── compare.html          Side-by-side comparison table
│   ├── about.html            Mission, vision, history timeline, partners
│   ├── services.html         Installation, training, maintenance, support, warranty, repairs
│   ├── contact.html          Office info, map placeholder, contact form
│   └── faq.html              Accordion FAQ
└── README.md
```

Built with **HTML5 + Bootstrap 5 + custom CSS + vanilla JavaScript**. No build step —
open `index.html` directly in a browser, or upload the folder as-is to any host.

Cart, wishlist and compare use browser `localStorage`, so they persist per-visitor
without needing a database yet. WhatsApp ordering is wired on every product card and
the product detail page, pre-filling the message with product name, price and link.

## Still to build (same Phase 1, next passes)

These follow the same pattern as the pages already built — I'll build them
next unless you want to reprioritize:

- `pages/blog.html` + individual article template
- `pages/request-quote.html`, `pages/track-order.html`
- `pages/request-quote.html`
- Full product database (Yinghe / World Colour large-format printers, Bizhub /
  Sharp copiers, YH-JWK laser machines, heat press models, spare parts) — currently
  8 sample products are wired in `shop.html` and `index.html` as a working template
- Custom SVG icon set, category banners, CTA graphics, loading animation
- Image optimization pass once you provide real product photos

## Phase 2 — Backend (separate build, needs real hosting)

Not runnable from a static file — needs a server, database and API keys:

- Node.js + Express REST API
- MongoDB or PostgreSQL product/order database
- Customer accounts (login/signup/forgot password), sessions
- Admin dashboard: products, orders, inventory, coupons, reports, analytics
- Paystack + Flutterwave payment integration
- Real checkout flow (cart.html currently works as a browser-only cart; wiring it to
  real payment requires this backend)

Recommended path for Phase 2: build and test locally with **Claude Code**, then deploy
to a Node-friendly host (Railway, Render, or a VPS with PM2 + Nginx). I can generate
the backend code either way — it just can't run live inside this chat.

## Going live with Phase 1 today

1. Buy a domain (e.g. `leifrolimited.com`)
2. Get hosting that supports static files (Netlify, Vercel, or any cPanel host)
3. Upload this folder
4. Free SSL is usually automatic with the above hosts
5. Point the domain's nameservers/DNS at your host

This gets the WhatsApp-ordering storefront live immediately, while Phase 2
(accounts, real checkout, admin panel) is built in parallel.
